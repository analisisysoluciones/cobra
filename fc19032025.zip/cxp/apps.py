from django.apps import AppConfig


class CxpConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cxp'
